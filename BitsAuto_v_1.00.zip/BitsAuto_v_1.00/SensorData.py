from typing import Dict, Any, List
from datetime import datetime


class SensorData:

    # This class stores and manages live sensor data from each sensor.

    def __init__(self, data: Dict[str, List[Any]] = None):

        self.__data: Dict[str, List[Any]] = data if data else {}
        self.__timestamp: Dict[str, List[datetime]] = {}
        self.__frame_id: Dict[str, List[int]] = {}


    def add_sensor_data(self, sensor_type: str, sensor_data: Any):

        # Adds new sensor data along with a timestamp and frame ID.
        # Initialize storage for new sensor types if they don’t exist
        if sensor_type not in self.__data:
            self.__data[sensor_type] = []
            self.__timestamp[sensor_type] = []
            self.__frame_id[sensor_type] = []

        # Append new data, timestamp, and a new frame ID
        self.__data[sensor_type].append(sensor_data)
        self.__timestamp[sensor_type].append(datetime.now())
        self.__frame_id[sensor_type].append(len(self.__frame_id[sensor_type]) + 1)


    
    def get_data(self, sensor_type: str) -> List[Any]:

        return self.__data.get(sensor_type, [])

    def get_timestamp(self, sensor_type: str) -> List[datetime]:

        return self.__timestamp.get(sensor_type, [])

    def get_frame_id(self, sensor_type: str) -> List[int]:

        return self.__frame_id.get(sensor_type, [])



    def update_data(self, sensor):

        # Updates sensor data by capturing new data.
        if sensor.check_connection():
            self.add_sensor_data(sensor.get_sensor_type(), sensor.get_data())
        else:
            print("Camera Disconnected.")


    def clear_oldest_entries(self, sensor_type: str):
        # Clears the oldest data entry for sensor type to manage memory.
        if self.__data[sensor_type]:

            print("Clearing Old Data")
            # Remove the oldest data, timestamp, and frame ID
            try:
                self.__data[sensor_type].pop(0)
                self.__timestamp[sensor_type].pop(0)
                self.__frame_id[sensor_type].pop(0)
            except IndexError:
                print("One or More Values Missing.")
