import numpy as np

class Pose:
    """
    This class stores the current position of the vehicle based on point cloud data.

    Try not to modify this class.
    """


    def __init__(self):

        self.__translation: np.ndarray = ...
        self.__rotation: np.ndarray = ...

    # getter methods

    def get_translation(self) -> np.ndarray:

        return self.__translation

    def get_rotation(self) -> np.ndarray:

        return self.__rotation

    # setter methods

    def set_translation(self, translation: np.ndarray) -> None:

        self.__translation = translation

    def set_rotation(self, rotation: np.ndarray) -> None:

        self.__rotation = rotation