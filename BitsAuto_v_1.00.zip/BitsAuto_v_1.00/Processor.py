from abc import ABC, abstractmethod
from SensorManager import SensorManager


class Processor(ABC):
    """
    This is the general Processor for all types of sensors.

    Try not to modify this class.
    """


    def __init__(self):

        self.sensor_manager = SensorManager()

    @abstractmethod
    def process_data(self):

        pass