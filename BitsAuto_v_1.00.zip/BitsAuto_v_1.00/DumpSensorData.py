from datetime import timedelta, datetime
from SensorData import SensorData


class DumpSensorData:
    # This class periodically clears old data entries from SensorData to manage memory usage.

    def __init__(self, sensor_data: SensorData, interval_minutes: float = 60.0, sensor_type: str = ""):
        # Initializes with a SensorData instance and a clearing interval (default 60 minutes).
        self.sensor_data = sensor_data
        self.clear_interval = timedelta(minutes=interval_minutes)
        self.next_clear_time = datetime.now() + self.clear_interval
        self.sensor_type = sensor_type

    def get_clear_interval(self):
        return self.clear_interval


    def set_clear_interval(self, interval: float = 60.0, unit: str = "minutes"):
        # Sets the interval for clearing data based on specified unit and interval.
        if unit == "minutes":
            self.clear_interval = timedelta(minutes=interval)
        elif unit == "seconds":
            self.clear_interval = timedelta(seconds=interval)
        elif unit == "hours":
            self.clear_interval = timedelta(hours=interval)
        else:
            raise ValueError("Invalid time unit. Use 'seconds', 'minutes', or 'hours'.")

        # Update the next clear time whenever the interval changes
        self.next_clear_time = datetime.now() + self.clear_interval


    def schedule_clear_once(self):
        # Checks the time and clears data if the interval has passed.
        if datetime.now() >= self.next_clear_time:
            self.clear_data()


    def clear_data(self):
        # Calls SensorData's clear_oldest_entries method and schedules the next clearing
        self.sensor_data.clear_oldest_entries(self.sensor_type)  # Clears the oldest entries in SensorData
        self.next_clear_time = datetime.now() + self.clear_interval
