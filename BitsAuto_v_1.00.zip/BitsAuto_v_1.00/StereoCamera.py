from Sensor import Sensor
import cv2
import numpy as np
from typing import Tuple, Dict, Any, List
from SensorData import SensorData

class StereoCamera(Sensor):
    """
    StereoCamera Sensor class for capturing and processing stereo images.
    """

    def __init__(self, sensor_id: str = "", left_camera_index: int = 0, right_camera_index: int = 1):
        super().__init__(sensor_id, "StereoCamera")

        self.__connected: bool = False
        self.__calibrated: bool = False
        self.__left_camera_index: int = left_camera_index
        self.__right_camera_index: int = right_camera_index

        # Initialize cameras
        self.__left_camera: cv2.VideoCapture = cv2.VideoCapture(self.__left_camera_index)
        self.__right_camera: cv2.VideoCapture = cv2.VideoCapture(self.__right_camera_index)

        self.__left_image: np.ndarray = np.asarray([])
        self.__right_image: np.ndarray = np.asarray([])
        self.__point_cloud: np.ndarray = np.asarray([])
        self.__previous_images: Tuple[np.ndarray, np.ndarray] = (np.asarray([]), np.asarray([]))

        self.__calibration_images: List = ...  # Ellipsis is a placeholder for now
        self.__checkerboard_size: Tuple[int, int] = ...  # Ellipsis is a placeholder for now

        self.__Q = None

    # Getter methods
    def get_connected(self) -> bool:
        return self.__connected

    def get_calibrated(self) -> bool:
        return self.__calibrated

    def get_left_camera_index(self) -> int:
        return self.__left_camera_index

    def get_right_camera_index(self) -> int:
        return self.__right_camera_index

    def get_left_image(self) -> np.ndarray:
        return self.__left_image

    def get_right_image(self) -> np.ndarray:
        return self.__right_image

    def initialize(self, sensor_data: SensorData) -> None:
        """
        Initializes the sensor for data collection.
        """
        self.__connected = self.check_connection()
        if self.__connected:
            self.calibrate(calibration_images=self.__calibration_images, checkerboard_size=self.__checkerboard_size)
            if self.__calibrated:
                print("Sensor Setup Confirmed.")
            else:
                print("Calibration Failed.")
        else:
            print("Connection to cameras failed.")

    def get_data(self) -> Dict[str, Any]:
        """
        Returns processed data including stereo images and point cloud (if computed).
        """

        self.capture_stereo_images()
        self.compute_visual_odometry()
        self.compute_disparity_and_point_cloud()

        data = {
            "left_image": self.__left_image,
            "right_image": self.__right_image,
            "point_cloud": self.__point_cloud
        }

        return data

    def check_connection(self) -> bool:
        """
        Checks if both cameras are connected and accessible.
        """
        left_connected = self.__left_camera.isOpened()
        right_connected = self.__right_camera.isOpened()
        self.__connected = left_connected and right_connected
        return self.__connected

    def shutdown(self) -> None:
        """
        Releases the cameras and cleans up resources.
        """
        if self.__left_camera.isOpened():
            self.__left_camera.release()
        if self.__right_camera.isOpened():
            self.__right_camera.release()
        self.__connected = False
        self.__calibrated = False
        print("Cameras have been shut down.")

    def capture_stereo_images(self) -> None:
        """
        Captures synchronized images from both cameras.
        """

        # Read images from both cameras
        ret_left, left_image = self.__left_camera.read()
        ret_right, right_image = self.__right_camera.read()

        if ret_left and ret_right:
            self.__previous_images = (self.__left_image, self.__right_image)
            self.__left_image, self.__right_image = left_image, right_image
        else:
            print("Failed to capture images from both cameras.")

    def compute_visual_odometry(self) -> None:
        """
        Computes visual odometry between consecutive stereo image pairs.
        """
        if len(self.__previous_images[0]) == 0 or len(self.__previous_images[1]) == 0:
            print("No previous images available for visual odometry.")
            return

        # Convert images to grayscale
        left_gray = cv2.cvtColor(self.__previous_images[0], cv2.COLOR_BGR2GRAY)
        right_gray = cv2.cvtColor(self.__previous_images[1], cv2.COLOR_BGR2GRAY)

        # Detect features and match between left and right images
        orb = cv2.ORB_create()
        keypoints_left, descriptors_left = orb.detectAndCompute(left_gray, None)
        keypoints_right, descriptors_right = orb.detectAndCompute(right_gray, None)

        # Match features
        bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
        matches = bf.match(descriptors_left, descriptors_right)
        matches = sorted(matches, key=lambda x: x.distance)

        # (Optional) Compute transformation based on matched keypoints
        # Code for transformation computation goes here if needed.

        # Print out number of matches found
        print(f"Found {len(matches)} feature matches between stereo images.")

    def calibrate(self, calibration_images: list, checkerboard_size: Tuple[int, int]) -> None:
        """
        Calibrates the stereo camera system using captured calibration images.
        :param calibration_images: List of stereo image pairs [(left_image, right_image)] used for calibration.
        :param checkerboard_size: Dimensions of the checkerboard pattern (columns, rows).
        """
        print("Starting calibration...")

        # Prepare object points (3D points in real-world space) based on checkerboard size
        objp = np.zeros((checkerboard_size[0] * checkerboard_size[1], 3), np.float32)
        objp[:, :2] = np.mgrid[0:checkerboard_size[0], 0:checkerboard_size[1]].T.reshape(-1, 2)

        objpoints = []  # 3D points in the real world
        imgpoints_left = []  # 2D points from the left camera
        imgpoints_right = []  # 2D points from the right camera

        # Iterate through all stereo image pairs for calibration
        for pair in calibration_images:
            left_gray = cv2.cvtColor(pair[0], cv2.COLOR_BGR2GRAY)
            right_gray = cv2.cvtColor(pair[1], cv2.COLOR_BGR2GRAY)

            # Detect checkerboard corners in both images
            ret_left, corners_left = cv2.findChessboardCorners(left_gray, checkerboard_size)
            ret_right, corners_right = cv2.findChessboardCorners(right_gray, checkerboard_size)

            if ret_left and ret_right:
                objpoints.append(objp)
                imgpoints_left.append(corners_left)
                imgpoints_right.append(corners_right)

        # Calibrate each camera independently
        _, camera_matrix_left, dist_coeffs_left, _, _ = cv2.calibrateCamera(
            objpoints, imgpoints_left, left_gray.shape[::-1], None, None)
        _, camera_matrix_right, dist_coeffs_right, _, _ = cv2.calibrateCamera(
            objpoints, imgpoints_right, right_gray.shape[::-1], None, None)

        # Stereo calibration to compute the rotation and translation between cameras
        _, _, _, _, _, R, T, _, _ = cv2.stereoCalibrate(
            objpoints, imgpoints_left, imgpoints_right,
            camera_matrix_left, dist_coeffs_left,
            camera_matrix_right, dist_coeffs_right,
            left_gray.shape[::-1], flags=cv2.CALIB_FIX_INTRINSIC)

        # Rectification matrices for aligning both cameras
        _, _, _, _, _, _, self.__Q = cv2.stereoRectify(
            camera_matrix_left, dist_coeffs_left,
            camera_matrix_right, dist_coeffs_right,
            left_gray.shape[::-1], R, T)

        self.__calibrated = True
        print("Calibration completed successfully.")


    def compute_disparity_and_point_cloud(self) -> None:
        """
        Computes the disparity map and generates a 3D point cloud from the stereo images.
        This requires the camera system to be calibrated.
        """
        if not self.__calibrated:
            print("Calibration is required before computing disparity.")
            return

        # Convert stereo images to grayscale
        left_gray = cv2.cvtColor(self.__left_image, cv2.COLOR_BGR2GRAY)
        right_gray = cv2.cvtColor(self.__right_image, cv2.COLOR_BGR2GRAY)

        # Compute disparity map using block-matching algorithm
        print("Computing disparity map...")
        stereo = cv2.StereoBM_create(numDisparities=16, blockSize=15) #test varying numDisparities and blockSize values 
        disparity = stereo.compute(left_gray, right_gray)

        # Reproject disparity map to 3D space to generate point cloud
        print("Generating point cloud...")
        self.__point_cloud = cv2.reprojectImageTo3D(disparity, self.__Q)
        print("Point cloud generated successfully.")

        # TODO: maybe in future replace print statements with a proper logging system

