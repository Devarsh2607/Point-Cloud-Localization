import numpy as np


class MapData:
    """
    This stores the point cloud data.

    Try not to modify this class.
    """


    def __init__(self):

        self.__point_cloud: np.ndarray = ...

    # getter methods

    def get_map(self) -> np.ndarray:

        return self.__point_cloud

    # setter methods

    def set_map(self, point_cloud: np.ndarray) -> None:

        self.__point_cloud = point_cloud
