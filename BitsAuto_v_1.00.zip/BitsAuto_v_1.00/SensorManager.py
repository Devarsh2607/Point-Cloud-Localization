from Sensor import Sensor
from typing import Dict

from SensorData import SensorData
from StereoCamera import StereoCamera


class SensorManager:
    """
    This class manages all the sensors and the live sensor_data storage.

    Please modify the class as per requirements....
    """


    def __init__(self):


        sensor1 = StereoCamera()  # add the parameters
        self.__sensors: Dict[str, Sensor] = {sensor1.get_sensor_type(): sensor1}  # initialize the dictionary
        self.__sensor_status: Dict[str, bool] = ...

        self.__sensor_data = SensorData()


    # The below function might not be required
    # def add_sensor(self, sensor: Sensor) -> None:
    #
    #     self.__sensors[sensor.get_sensor_type()] = sensor
    #     self.__sensor_data.add_sensor_data(sensor.get_sensor_type(), ...)


    def get_sensor(self, sensor_type: str) -> Sensor:

        return self.__sensors[sensor_type]

    def get_all_sensors(self) -> Dict[str, Sensor]:

        return self.__sensors

    def get_sensor_data(self) -> SensorData:

        return self.__sensor_data

    def initialize_sensors(self) -> None:

        for name, sensor in self.__sensors:

            sensor.initialize(self.__sensor_data)

    def initialize_specific_sensor(self, sensor_type: str) -> None:

        self.__sensors[sensor_type].initialize(self.__sensor_data)

    def read_sensor_data(self):

        sensors = list(self.__sensors.values())
        sensor_type = list(self.__sensors.keys())
        data = {}

        for i, sensor in enumerate(sensors):

            self.__sensor_data.update_data(sensor)
            data[sensor_type[i]] = self.__sensor_data.get_data(sensor_type[i])

        return data

    def read_specific_sensor_data(self, sensor_type: str):

        self.__sensor_data.update_data(self.__sensors[sensor_type])
        return self.__sensor_data.get_data(sensor_type)

    def get_sensor_status(self):

        sensors = list(self.__sensors.values())
        sensor_type = list(self.__sensors.keys())
        connections = {}

        for i, sensor in enumerate(sensors):
            self.__sensor_data.update_data(sensor)
            connections[sensor_type[i]] = self.__sensors[sensor_type[i]].check_connection()

        return connections

    def get_specific_sensor_status(self, sensor_type: str):

        return self.__sensors[sensor_type].check_connection()

    def shutdown_sensors(self) -> None:

        for name, sensor in self.__sensors:
            sensor.shutdown()

    def shutdown_specific_sensor(self, sensor_type: str) -> None:

        self.__sensors[sensor_type].shutdown()
