from datetime import datetime
from abc import ABC, abstractmethod
from typing import Dict, Any

from SensorData import SensorData


class Sensor(ABC):
    """
    This is the general sensor class for all types of sensors.

    Try not to modify this class.
    """


    def __init__(self, sensor_id: str = "", sensor_type: str = "", ):

        self.__sensor_id: str = sensor_id
        self.__sensor_type: str = sensor_type

        self._data: Dict[str, Any] = ...  # to be initialized later
        self._timestamp: datetime = ...  # to be initialized later
        self._frame_id: int = 0  # default value set to 0


    # Getter methods

    def get_sensor_id(self) -> str:

        return self.__sensor_id

    def get_sensor_type(self) -> str:

        return self.__sensor_type

    def get_timestamp(self) -> datetime:

        return self._timestamp

    def get_frame_id(self) -> int:

        return self._frame_id

    # setter methods to be defined here if necessary:

    # ..........
    # ..........

    # initializes the Sensor
    @abstractmethod
    def initialize(self, sensor_data: SensorData) -> None:

        pass

    # gets the data stored in data variable from the specific sensor class
    @abstractmethod
    def get_data(self) -> Dict[str, Any]:

        pass

    @abstractmethod
    def check_connection(self) -> bool:

        pass

    @abstractmethod
    def shutdown(self) -> None:

        pass
