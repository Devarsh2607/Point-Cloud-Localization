import numpy as np


class PoseChange:
    """
    This class stores the change in position of the vehicle.

    Try not to modify this class.
    """


    def __init__(self):

        self.__delta_translation: np.ndarray = ...
        self.__delta_rotation: np.ndarray = ...

    # getter methods

    def get_delta_translation(self) -> np.ndarray:
        return self.__delta_translation

    def get__delta_rotation(self) -> np.ndarray:
        return self.__delta_rotation

    # setter methods

    def set_translation(self, delta_translation: np.ndarray) -> None:
        self.__delta_translation = delta_translation

    def set_rotation(self, delta_rotation: np.ndarray) -> None:
        self.__delta_rotation = delta_rotation
