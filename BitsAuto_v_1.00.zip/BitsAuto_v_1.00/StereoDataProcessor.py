from DumpSensorData import DumpSensorData
from Pose import Pose
from PoseChange import PoseChange
from MapData import MapData
from Processor import Processor
from typing import List


class StereoDataProcessor(Processor):
    """
    This is the StereoDataProcessor which processes the data collected from the StereoCamera sensor specifically.
    """

    def __init__(self):

        super().__init__()
        self.__map_data: MapData = MapData()
        self.current_pos: Pose = Pose()
        self.sensor_manager.initialize_specific_sensor("StereoCamera")
        interval_minutes = 1.0  # Set as per convenience
        self.dump_stereo_data = DumpSensorData(self.sensor_manager.get_sensor_data(), interval_minutes=interval_minutes,
                                               sensor_type="StereoCamera")

        self.__run = False

    def process_stereo_images(self) -> MapData:
        """
        Processes the stereo images using StereoCamera functions.
        Returns the depth map created from the stereo images.
        """
        map_data: MapData = MapData()
        data = self.sensor_manager.read_specific_sensor_data("StereoCamera")
        if isinstance(data, List):
            pass
        else:
            map_data.set_map(data["point_cloud"][-1])
        # taking latest data by using -1 for index in the list of data that is returned

        return map_data

    def estimate_pose_change(self, current_depth_map: MapData) -> PoseChange:
        """
        Estimates the change in position based on the depth map.
        """
        pose_change = PoseChange()

        # TODO: Yet to be implemented

        return pose_change

    def update_pose(self, pose_change: PoseChange) -> None:
        """
        Updates the current position based on the estimated pose change.
        """
        
        # TODO: Yet to be implemented.

    def update_map(self, depth_map: MapData) -> None:
        """
        Updates the map data using the depth map and the current position.
        """
        self.__map_data.set_map(depth_map.get_map())

    def process_data(self) -> None:
        """
        Main processing function for the StereoDataProcessor.
        It coordinates capturing images, estimating pose change, updating pose, and updating map data.
        """

        self.__run: bool = True

        while self.__run:

            current_depth_map = self.process_stereo_images()
            pose_change = self.estimate_pose_change(current_depth_map)
            self.update_pose(pose_change)
            self.update_map(current_depth_map)
            self.dump_stereo_data.schedule_clear_once()

            try:
                terminating = open("Terminate.txt", 'r')
                # TODO: Existence of a Terminate.txt file causes the loop to break so we need a parallel process to create an
                # TODO: empty Terminate.txt file for termination.
                self.__run = False
                self.sensor_manager.shutdown_specific_sensor("StereoCamera")
            except FileNotFoundError:
                pass

            if not self.sensor_manager.get_specific_sensor_status(sensor_type="StereoCamera"):

                self.__run = False

    def get_map(self) -> MapData:

        return self.__map_data

if __name__ == "__main__":

    StereoDataProcessor().process_data()